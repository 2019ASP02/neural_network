import React,  { useState, useEffect } from "react";
import axios from "axios";
import "./Admin.css"

const PostNewVacancy = () => {
    
    const [vacancies, setVacancies] = useState([]);
    const [applicants, setApplicants] = useState([]);
    const [newJob, setNewJob] = useState({ job_name: "", years_of_experience: "", description: "" });

    
    useEffect(() => {
        axios.get("http://127.0.0.1:8000/vacancies")
            .then(response => {
                console.log("Vacancies data:", response.data);
                setVacancies(response.data);
            })
            .catch(error => console.error("Error fetching vacancies:", error));

        axios.get("http://127.0.0.1:8000/applications")
            .then(response => {
                console.log("Applications data:", response.data);
                setApplicants(response.data);
            })
            .catch(error => console.error("Error fetching applications:", error));
    }, []);

    const handlePostJob = (e) => {
        e.preventDefault();
        
        // Get today's date in YYYY-MM-DD format
        const today = new Date().toISOString().split("T")[0];
    
        const formData = new FormData();
        formData.append("job_name", newJob.job_name);
        formData.append("years_of_experience", parseInt(newJob.years_of_experience) || 0);
        formData.append("description", newJob.description);
        formData.append("post_date", today); // Automatically set today's date
        formData.append("close_date", newJob.close_date || today); // Default to today if not provided
        formData.append("no_of_vacancies", parseInt(newJob.no_of_vacancies) || 1);
    
        console.log("FormData being sent:", Object.fromEntries(formData));
    
        axios.post("http://127.0.0.1:8000/vacancies", formData, {
            headers: {
                "Content-Type": "multipart/form-data",
            },
        })
            .then(response => {
                setVacancies([...vacancies, response.data.job]);
                setNewJob({ job_name: "", years_of_experience: "", description: "", close_date: "", no_of_vacancies: "" });
                window.alert("Job posted successfully!");
            })
            .catch(error => console.error("Error posting job:", error));
            alert("Application submitted successfully!.");
    };
    
    /*const handlePostJob = (e) => {
        e.preventDefault();
        const formData = new FormData();
        formData.append("job_name", newJob.job_name);
        formData.append("years_of_experience", parseInt(newJob.years_of_experience) || 0);
        formData.append("description", newJob.description);
        console.log("FormData being sent:", formData); // Log the FormData
        axios.post("http://127.0.0.1:8000/vacancies", formData, {
            headers: {
                'Content-Type': 'multipart/form-data'
            }
        })
            .then(response => {
                setVacancies([...vacancies, response.data.job]);
                setNewJob({ job_name: "", years_of_experience: "", description: "" });
                window.alert("Job posted successfully!");
            })
            .catch(error => console.error("Error posting job:", error));
    };
    

    const handleDeleteJob = (job_id) => {
        axios.delete(`http://127.0.0.1:8000/vacancies/${job_id}`)
            .then(() => {
                setVacancies(vacancies.filter(job => job.job_id !== job_id));
            })
            .catch(error => console.error("Error deleting job:", error));
    };*/

    const handleDeleteJob = (job_id) => {
        axios.delete(`http://127.0.0.1:8000/vacancies/${job_id}`)
            .then(() => {
                setVacancies(vacancies.filter(job => job.job_id !== job_id));
            })
            .catch(error => console.error("Error deleting job:", error));
    };

    const handleDeleteApplicant = (id) => {
        axios.delete(`http://127.0.0.1:8000/applications/${id}`)
            .then(() => {
                setApplicants(applicants.filter(applicant => applicant.id !== id));
            })
            .catch(error => console.error("Error deleting application:", error));
    };

    return (
        <div>
        <h3 className="m">Post New Vacancy</h3>
            <form onSubmit={handlePostJob} className="mb-4">
                <div className="mb-2">
                    <label className="te">Job Name</label>
                    <input
                        type="text"
                        placeholder="Job Name"
                        value={newJob.job_name}
                        onChange={(e) => setNewJob({ ...newJob, job_name: e.target.value })}
                        className="mt-1 block w-full border-gray-300 rounded-md shadow-sm"
                        required
                    />
                </div>
                <div className="mb-2">
                    <label className="te">Years of Experience</label>
                    <input
                        type="number"
                        placeholder="Years of Experience"
                        value={newJob.years_of_experience}
                        onChange={(e) => setNewJob({ ...newJob, years_of_experience: e.target.value })}
                        className="mt-1 block w-full border-gray-300 rounded-md shadow-sm"
                        required
                    />
                </div>
                <div className="mb-2">
                    <label className="te">Description</label>
                    <textarea
                        placeholder="Description"
                        value={newJob.description}
                        onChange={(e) => setNewJob({ ...newJob, description: e.target.value })}
                        className="mt-1 block w-full border-gray-300 rounded-md shadow-sm"
                        required
                    />
                </div>
                <div className="mb-2">
                    <label className="te">Close Date</label>
                    <input
                        type="date"
                        value={newJob.close_date}
                        onChange={(e) => setNewJob({ ...newJob, close_date: e.target.value })}
                        className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                        required
                    />
                </div>
                <div className="mb-2">
                    <label className="te">Number of Vacancies</label>
                    <input
                        type="number"
                        placeholder="Number of Vacancies"
                        value={newJob.no_of_vacancies}
                        onChange={(e) => setNewJob({ ...newJob, no_of_vacancies: e.target.value })}
                        className="mt-1 block w-full border-gray-300 rounded-md shadow-sm"
                        required
                    />
                </div>
                <button type="submit" className="post-button">
                    Post Job
                </button>
            </form>
            </div>
    );
};

export default PostNewVacancy;
