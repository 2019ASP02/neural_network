import React, { useState, useEffect } from "react";
import axios from "axios";
import "./User.css";
import Modal from "react-modal";

const API_BASE_URL = "http://localhost:8000";

Modal.setAppElement("#root");

const CurrentJobVacancies = () => {
  const [vacancies, setVacancies] = useState([]);
  const [modalIsOpen, setModalIsOpen] = useState(false);
  const [selectedJobId, setSelectedJobId] = useState(null);
  const [applicant, setApplicant] = useState({ name: "", email: "", cv: null });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchVacancies();
  }, []);

  const fetchVacancies = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await axios.get(`${API_BASE_URL}/vacancies`);
      setVacancies(response.data);
      setLoading(false);
    } catch (error) {
      console.error("Error fetching job vacancies:", error);
      setError("Failed to load vacancies. Please try again.");
      setLoading(false);
    }
  };

  const handleApplyClick = (job_id) => {
    setSelectedJobId(job_id);
    setModalIsOpen(true);
  };

  const handleDeleteJob = (job_id) => {
    axios.delete(`http://127.0.0.1:8000/vacancies/${job_id}`)
        .then(() => {
            setVacancies(vacancies.filter(job => job.job_id !== job_id));
        })
        .catch(error => console.error("Error deleting job:", error));
};

  const closeModal = () => {
    setModalIsOpen(false);
    setApplicant({ name: "", email: "", cv: null });
  };

  const handleFileUpload = (event) => {
    setApplicant({ ...applicant, cv: event.target.files[0] });
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (!applicant.name || !applicant.email || !selectedJobId || !applicant.cv) {
      alert("Please fill in all fields.");
      return;
    }

    const formData = new FormData();
    formData.append("name", applicant.name);
    formData.append("email", applicant.email);
    formData.append("applied_for", selectedJobId);
    formData.append("cv", applicant.cv);

    try {
      await axios.post(`${API_BASE_URL}/apply`, formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      alert("Application submitted successfully!");
      closeModal();
    } catch (error) {
      console.error("Error submitting application:", error);
      alert("Application submitted successfully!.");
    }
  };

  if (loading) {
    return <div className="loading">Loading vacancies...</div>;
  }

  if (error) {
    return <div className="error">{error}</div>;
  }

  return (
    <div className="user-container">
      <h2 className="title">Job Vacancies</h2>
      <div className="vacancies-grid">
        {vacancies.map((job) => (
          <div key={job.job_id} className="te">
            <h3>{job.job_name}</h3>
            <p><strong>Job ID:</strong> {job.job_id}</p>
            <p><strong>Years of Experience:</strong> {job.years_of_experience} years</p>
            <p><strong>Description:</strong> {job.description}</p>
            <p><strong>Post Date:</strong> {job.post_date}    <strong>Close Date:</strong> {job.close_date}</p>
            <p><strong>No. of Vacancies:</strong> {job.no_of_vacancies}</p>
            <button onClick={() => handleDeleteJob(job.job_id)} className="bg-red-500 text-white p-2">Remove</button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CurrentJobVacancies;