import React, { useState, useEffect } from "react";
import axios from "axios";
import JobApplicants from "./JobApplicants";
import PostNewVacancy from "./PostNewVacancy";
import CurrentJobVacancies from "./CurrentJobVacancies";
import ScheduleMeeting from "./ScheduleMeeting"; // Import the ScheduleMeeting component
import "./Admin.css";
import Header from './Header';
import Footer from './Footer';

const Admin = ({ onLogout }) => {
    const [vacancies, setVacancies] = useState([]);
    const [applicants, setApplicants] = useState([]);
    const [selectedCandidates, setSelectedCandidates] = useState([]); 
    const [activeTab, setActiveTab] = useState("currentVacancies");
    const [newJob, setNewJob] = useState({ job_name: "", years_of_experience: "", description: "" });
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        setLoading(true);

        Promise.all([
            axios.get("http://127.0.0.1:8000/vacancies"),
            axios.get("http://127.0.0.1:8000/applications"),
            axios.get("http://127.0.0.1:8000/selected_candidates") 
        ]).then(([vacanciesResponse, applicationsResponse, selectedCandidatesResponse]) => {
            setVacancies(vacanciesResponse.data);
            setApplicants(applicationsResponse.data);
            setSelectedCandidates(selectedCandidatesResponse.data);
            setLoading(false);
        }).catch(error => {
            console.error("Error fetching data", error);
            setLoading(false);
        });
    }, []);

    // Function to navigate to the "Schedule Meeting" tab
    const navigateToScheduleMeeting = () => {
        setActiveTab("scheduleMeeting");
    };

    return (
        <>
            <Header userType="admin" />
            <main>
                <div className="admin-container">
                    {/* Horizontal Tab Menu */}
                    <div className="tab-menu">
                        <div
                            className={`tab-item ${activeTab === "postNewVacancy" ? "active" : ""}`}
                            onClick={() => setActiveTab("postNewVacancy")}
                        >
                            Post New Vacancy
                        </div>
                        <div
                            className={`tab-item ${activeTab === "currentVacancies" ? "active" : ""}`}
                            onClick={() => setActiveTab("currentVacancies")}
                        >
                            Current Job Vacancies
                        </div>
                        <div
                            className={`tab-item ${activeTab === "jobApplicants" ? "active" : ""}`}
                            onClick={() => setActiveTab("jobApplicants")}
                        >
                            Job Applicants
                        </div>
                        <div
                            className={`tab-item ${activeTab === "scheduleMeeting" ? "active" : ""}`}
                            onClick={() => setActiveTab("scheduleMeeting")}
                        >
                            Schedule Meeting
                        </div>
                    </div>

                    {/* Tab Content */}
                    <div className="tab-content">
                        {activeTab === "currentVacancies" && (
                            <CurrentJobVacancies
                                vacancies={vacancies}
                                setVacancies={setVacancies}
                            />
                        )}
                        {activeTab === "postNewVacancy" && (
                            <PostNewVacancy newJob={newJob} setNewJob={setNewJob} />
                        )}
                        {activeTab === "jobApplicants" && (
                            <JobApplicants
                                applicants={applicants}
                                setApplicants={setApplicants}
                            />
                        )}
                        {activeTab === "scheduleMeeting" && (
                            <ScheduleMeeting selectedCandidates={selectedCandidates} />
                        )}
                    </div>
                </div>
            </main>
            <Footer />
        </>
    );
};

export default Admin;
