import React from 'react';

const ScheduleMeeting = ({ selectedCandidates }) => {
    const handleScheduleMeeting = (candidateId) => {
        // Logic to schedule the meeting for the selected candidate
        alert(`Meeting scheduled for candidate ID: ${candidateId}`);
    };

    return (
        <div className="schedule-meeting-container">
            <h2 className="text-2xl font-semibold mb-4">Schedule Meeting</h2>
            {selectedCandidates.length === 0 ? (
                <p>No selected candidates for meetings.</p>
            ) : (
                <table className="w-full text-left border-separate border-spacing-2 bg-white shadow-xl rounded-lg">
                    <thead className="bg-teal-800 text-white">
                        <tr>
                            <th className="py-3 px-6">Name</th>
                            <th className="py-3 px-6">Email</th>
                            <th className="py-3 px-6">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        {selectedCandidates.map((candidate) => (
                            <tr key={candidate.id} className="border-b hover:bg-teal-50">
                                <td className="py-3 px-6">{candidate.name}</td>
                                <td className="py-3 px-6">{candidate.email}</td>
                                <td className="py-3 px-6">
                                    <button
                                        onClick={() => handleScheduleMeeting(candidate.id)}
                                        className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
                                    >
                                        Schedule Meeting
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            )}
        </div>
    );
};

export default ScheduleMeeting;
